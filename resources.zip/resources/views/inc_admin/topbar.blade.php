<div class="middle-sidebar-header bg-white">
                <button class="header-menu"></button>
                <form action="#" class="float-left header-search">
                    <div class="form-group mb-0 icon-input">
                        <i class="feather-search font-lg text-grey-400"></i>
                        <input type="text" placeholder="Start typing to search.." class="bg-transparent border-0 lh-32 pt-2 pb-2 pl-5 pr-3 font-xsss fw-500 rounded-xl w350">
                    </div>
                </form>
                <ul class="d-flex ml-auto right-menu-icon">
                <li>
                        <a href="#"><span class="dot-count bg-warning"></span><i class="feather-bell font-xl text-current"></i>
                       
                        </a>
                    </li>
                    <!-- <li><a href="/message/0"><i class="feather-message-square font-xl text-current"></i></a></li> -->
                  
                    <!-- <li><a href="default_user_profile"><img src="https://via.placeholder.com/50x50.png" alt="user" class="w40 rounded-circle mt--1"></a></li> -->
                    <li><a href="#" class="menu-search-icon"><i class="feather-search text-grey-900 font-lg"></i></a></li>
                </ul>
            </div>