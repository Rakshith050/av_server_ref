<div class="app-footer border-0 shadow-lg">
    <a href="/aprex/default_live_stream/<?php echo $data['course']->id; ?>/0" class="nav-content-bttn nav-center"><i style="background:orange;color:#fff !important;padding:6px;border-radius:50%" class="feather-book-open"></i></a>
    <a href="/aprex/video_player_mobile/<?php echo $data['course']->id ?>" class="nav-content-bttn"><i style="background:orange;color:#fff !important;padding:6px;border-radius:50%" class="feather-video"></i></a>
    <a href="/aprex/chat/<?php echo $data['course']->id ?>" class="nav-content-bttn" data-tab="chats"><i style="background:orange;color:#fff !important;padding:6px;border-radius:50%"
            class="feather-message-circle"></i></a>
    <a href="/aprex/notes/<?php echo $data['course']->id ?>" class="nav-content-bttn"><i style="background:orange;color:#fff !important;padding:6px;border-radius:50%" class="feather-file-text"></i></a>
    <a href="/aprex/index" class="nav-content-bttn"><i class="feather-home"></i></a>
   
</div>