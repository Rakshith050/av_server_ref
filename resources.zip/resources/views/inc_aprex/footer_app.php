<div class="app-footer border-0 shadow-lg">
    <a href="/aprex/index" class="nav-content-bttn nav-center"><i class="feather-home"></i></a>
    <a href="/aprex/all_courses" class="nav-content-bttn"><i class="feather-package"></i></a>
    <a href="/aprex/jobs" class="nav-content-bttn" data-tab="chats"><i class="feather-layout"></i></a>
   
    <a href="#" class="sidebar-right nav-content-bttn"><img src="https://static.wixstatic.com/media/27377b_e307ba1f4fde40ee927fb13b2858cb75~mv2.gif" alt="user" class="w30 shadow-xss"></a>
</div>



